"""
SAM CLI version
"""

__version__ = "1.136.0"
